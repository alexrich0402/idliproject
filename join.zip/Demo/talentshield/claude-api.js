// Claude API integration for ATS scoring

// Note: In a real-world application, API keys should be securely managed
// on the server-side to protect sensitive credentials
const CLAUDE_API_KEY = "your-claude-api-key"; // Replace with your actual API key

// Function to extract text from PDF using PDF.js
async function extractTextFromPDF(dataUrl) {
    return new Promise((resolve, reject) => {
        if (!pdfjsLib) {
            reject(new Error("PDF.js is not loaded"));
            return;
        }

        // Remove data URL prefix to get base64 data
        const loadingTask = pdfjsLib.getDocument(dataUrl);
        
        loadingTask.promise.then(async (pdf) => {
            let fullText = '';
            
            // Extract text from all pages
            for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
                const page = await pdf.getPage(pageNum);
                const textContent = await page.getTextContent();
                
                // Concatenate text from the page
                const pageText = textContent.items.map(item => item.str).join(' ');
                fullText += pageText + '\n';
            }
            
            resolve(fullText);
        }).catch(error => {
            console.error("Error extracting PDF text:", error);
            reject(error);
        });
    });
}

// Function to analyze resume with Claude API
async function analyzeResumeWithClaude(resumeText, position) {
    try {
        console.log("Analyzing resume for position:", position);
        
        // Construct the prompt for Claude
        const prompt = `
You are an expert ATS (Applicant Tracking System) analyzer.
        
Analyze this resume for a "${position}" position:
${resumeText}

Evaluate how well this resume matches typical requirements for this position.
Consider keywords, experience, skills, and formatting.

Provide a response in this JSON format:
{
    "score": number (0-100),
    "feedback": string,
    "keywordMatches": string[],
    "missingKeywords": string[],
    "improvedContent": string
}
        `;
        
        // In a real-world scenario, this would be a server-side API call
        // This is a simulated response for demonstration
        return {
            score: Math.floor(Math.random() * 40) + 60, // Random score between 60-100
            feedback: "Your resume shows promise for the " + position + " role. Consider highlighting more specific achievements and tailoring your skills to the job description.",
            keywordMatches: [
                "project management", 
                "team collaboration", 
                "problem-solving"
            ],
            missingKeywords: [
                "agile methodology", 
                "cross-functional teams", 
                "performance optimization"
            ],
            improvedContent: "Add more quantifiable achievements, use industry-specific keywords, and align your summary with the job requirements."
        };
        
        // Uncomment and modify the following block when you have actual Claude API access
        /*
        const response = await fetch("https://api.anthropic.com/v1/messages", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "x-api-key": CLAUDE_API_KEY,
                "anthropic-version": "2023-06-01"
            },
            body: JSON.stringify({
                model: "claude-3-opus-20240229",
                messages: [
                    { role: "user", content: prompt }
                ],
                max_tokens: 1000
            })
        });
        
        if (!response.ok) {
            throw new Error(`API request failed: ${response.status}`);
        }
        
        const data = await response.json();
        
        // Extract JSON content from Claude's response
        const responseText = data.content[0].text;
        const jsonMatch = responseText.match(/\{[\s\S]*\}/);
        
        if (jsonMatch) {
            return JSON.parse(jsonMatch[0]);
        } else {
            throw new Error("Failed to parse Claude's response");
        }
        */
    } catch (error) {
        console.error("Error analyzing resume with Claude:", error);
        throw new Error("Failed to analyze resume");
    }
}

// Main function to get ATS score
async function getATSScore(resumeDataUrl, position) {
    try {
        // Extract text from PDF
        const resumeText = await extractTextFromPDF(resumeDataUrl);
        
        // Analyze resume 
        const analysisResult = await analyzeResumeWithClaude(resumeText, position);
        
        return analysisResult;
    } catch (error) {
        console.error("Error getting ATS score:", error);
        throw new Error("Failed to score resume");
    }
}