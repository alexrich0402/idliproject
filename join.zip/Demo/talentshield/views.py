from django.shortcuts import render,redirect
from django.contrib.auth import login, authenticate, logout
from talentshield.forms import SignUpForm
from django.contrib import messages
from talentshield.models import CustomUser
from django.http import HttpResponse
from reportlab.pdfgen import canvas
import io

def index(request):
   return render(request, 'index.html') 
# Ensure this matches the template name
def resume(request):
   return render(request, 'resumebuilder.html')

def upload(request):
   return render(request, 'upload.html')

def option(request):
   return render(request, 'option.html')

def signup(request):
    return render(request, 'signup.html')

def results(request):
   return render(request, 'results.html')

def profile(request):
   return render(request, 'profile.html')
def login(request):
    return render(request, 'login.html')

def candidate(request):
    return render(request, 'candidate.html')

def hrmanager(request):
    return render(request, 'hrmanager.html')

def dashboard(request):
    return render(request, 'dashboard.html')

def resume(request):
    return render(request, 'resumebuilder.html')

# Add these functions to your talentshield/views.py file

from django.shortcuts import render

def candidate_dashboard(request):
    """
    View function for displaying the candidate dashboard.
    """
    return render(request, 'candidate.html')

def upload_documents(request):
    """
    View function for the document upload page.
    """
    return render(request, 'upload.html')

def profile(request):
    """
    View function for displaying the user's profile.
    """
    return render(request, 'profile.html')

def edit_profile(request):
    """
    View function for editing the user's profile.
    """
    return render(request, 'edit-profile.html')

def logout_view(request):
    """
    View function to log out a user and redirect to the login page.
    """
    logout(request)
    return redirect('login') 



import io
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.template.loader import get_template
import pdfkit

def calculate_resume_score(context):
    """
    Calculate a resume score based on completeness and content quality.
    Returns a score out of 100 and feedback for improvement.
    """
    score = 0
    feedback = []
    
    # Initialize scoring weights
    weights = {
        'personal_info': 15,
        'summary': 20,
        'experience': 25,
        'education': 15,
        'skills': 15,
        'certifications': 10
    }
    
    # Score personal information (name, email, phone, location)
    personal_score = 0
    if context.get('name'):
        personal_score += 5
    if context.get('email'):
        personal_score += 4
    if context.get('phone'):
        personal_score += 3
    if context.get('location'):
        personal_score += 3
    score += (personal_score / 15) * weights['personal_info']
    
    if personal_score < 15:
        feedback.append("Complete all personal information fields for better visibility.")
    
    # Score professional summary
    summary_score = 0
    summary = context.get('summary', '')
    if summary:
        # Basic length check (minimum 200 characters for a good summary)
        if len(summary) >= 200:
            summary_score += 15
        elif len(summary) >= 100:
            summary_score += 10
        else:
            summary_score += 5
            feedback.append("Expand your professional summary to at least 200 characters.")
        
        # Check for key terms like "experience", "skills", "expertise"
        keywords = ['experience', 'skills', 'expertise', 'qualified', 'professional', 
                   'accomplished', 'successful', 'background', 'knowledge']
        keyword_count = sum(1 for keyword in keywords if keyword.lower() in summary.lower())
        summary_score += min(keyword_count, 5)
    else:
        feedback.append("Add a professional summary to highlight your qualifications.")
    
    score += (summary_score / 20) * weights['summary']
    
    # Score work experience
    experience_score = 0
    if context.get('company') and context.get('position'):
        experience_score += 10
        
        # Check for duration
        if context.get('duration'):
            experience_score += 5
        else:
            feedback.append("Add employment duration to your experience.")
        
        # Check responsibilities description
        responsibilities = context.get('responsibilities', '')
        if responsibilities:
            if len(responsibilities) >= 200:
                experience_score += 10
            elif len(responsibilities) >= 100:
                experience_score += 5
                feedback.append("Provide more details about your responsibilities and achievements.")
        else:
            feedback.append("Describe your job responsibilities and achievements.")
    else:
        feedback.append("Add your work experience details.")
    
    score += (experience_score / 25) * weights['experience']
    
    # Score education
    education_score = 0
    education = context.get('education', {})
    if education.get('institution'):
        education_score += 5
    else:
        feedback.append("Add your educational institution.")
        
    if education.get('degree'):
        education_score += 7
    else:
        feedback.append("Include your degree or qualification.")
        
    if education.get('graduation_year'):
        education_score += 3
    else:
        feedback.append("Add your graduation year.")
    
    score += (education_score / 15) * weights['education']
    
    # Score skills
    skills_score = 0
    skills = context.get('skills', [])
    if skills:
        skill_count = len(skills)
        if skill_count >= 8:
            skills_score += 15
        elif skill_count >= 5:
            skills_score += 10
        elif skill_count >= 3:
            skills_score += 5
            feedback.append("Add more skills to showcase your capabilities (aim for at least 8).")
        else:
            feedback.append("List more of your professional skills.")
    else:
        feedback.append("Add your professional skills to the resume.")
    
    score += (skills_score / 15) * weights['skills']
    
    # Score certifications
    cert_score = 0
    certifications = context.get('certifications', [])
    if certifications:
        cert_count = len(certifications)
        if cert_count >= 2:
            cert_score += 10
        else:
            cert_score += 5
            feedback.append("Add more professional certifications if you have them.")
    else:
        feedback.append("Include professional certifications to boost your credibility.")
    
    score += (cert_score / 10) * weights['certifications']
    
    # Round the final score
    final_score = round(score)
    
    # Determine rating based on score
    if final_score >= 90:
        rating = "Excellent"
    elif final_score >= 80:
        rating = "Very Good"
    elif final_score >= 70:
        rating = "Good"
    elif final_score >= 60:
        rating = "Above Average"
    elif final_score >= 50:
        rating = "Average"
    else:
        rating = "Needs Improvement"
    
    # Limit to top 3 feedback items if there are too many
    if len(feedback) > 3:
        feedback = feedback[:3]
    
    return {
        'score': final_score,
        'rating': rating,
        'feedback': feedback
    }



def resume_builder(request):
    """View to render the resume builder interface"""
    return render(request, 'resumebuilder.html')

def generate_pdf(request):
    if request.method == "POST":
        # Get form data
        name = request.POST.get("name", "")
        email = request.POST.get("email", "")
        phone = request.POST.get("phone", "")
        location = request.POST.get("location", "")
        summary = request.POST.get("summary", "")
        
        # Work experience
        company = request.POST.get("company", "")
        position = request.POST.get("position", "")
        duration = request.POST.get("duration", "")
        responsibilities = request.POST.get("responsibilities", "")
        
        # Education
        institution = request.POST.get("institution", "")
        degree = request.POST.get("degree", "")
        graduation_year = request.POST.get("graduation_year", "")
        
        # Skills - assuming it's a comma-separated string
        skills_input = request.POST.get("skills", "")
        skills_list = [{'name': skill.strip()} for skill in skills_input.split(',') if skill.strip()]
        
        # Certification
        certification = request.POST.get("certification", "")
        organization = request.POST.get("organization", "")
        date_earned = request.POST.get("date_earned", "")
        
        # Get selected template
        selected_template = request.POST.get("selected_template", "professional")
        
        # Prepare education data structure to match our templates
        education = {
            'institution': institution,
            'degree': degree,
            'graduation_year': graduation_year,
        }
        
        # Prepare certifications data
        certifications = []
        if certification:
            certifications.append({
                'name': certification,
                'organization': organization,
                'date_earned': date_earned,
            })
        
        # Create context for template
        context = {
            'name': name,
            'email': email,
            'phone': phone,
            'location': location,
            'summary': summary,
            'position': position,
            'company': company,
            'duration': duration,
            'responsibilities': responsibilities,
            'education': education,
            'skills': skills_list,
            'certifications': certifications,
            'experiences': []  # Empty list for additional experiences
        }
        
        # Calculate resume score
        resume_score = calculate_resume_score(context)
        context['resume_score'] = resume_score
        
        # Determine template file based on selection
        template_mapping = {
            'professional': 'resume_templates/professional.html',
            'creative': 'resume_templates/creative.html',
            'technical': 'resume_templates/technical.html',
        }
        
        template_path = template_mapping.get(selected_template, 'resume_templates/professional.html')
        
        # Render the template with context
        template = get_template(template_path)
        html_string = template.render(context)
        
        # Set path to wkhtmltopdf.exe
        path_wkhtmltopdf = r'C:\Program Files\wkhtmltopdf\bin\wkhtmltopdf.exe'
        config = pdfkit.configuration(wkhtmltopdf=path_wkhtmltopdf)
        
        # PDF options
        options = {
            'page-size': 'Letter',
            'encoding': 'UTF-8',
            'no-outline': None,
            'enable-local-file-access': None
        }
        
        # Generate PDF
        pdf = pdfkit.from_string(html_string, False, options=options, configuration=config)
        
        # Create response
        response = HttpResponse(pdf, content_type='application/pdf')
        filename = f"{name.replace(' ', '_')}_resume.pdf"
        response['Content-Disposition'] = f'attachment; filename="{filename}"'
        
        return response
    
    # If not POST request, redirect to resume builder
    return redirect('resume_builder')




#upload view and candidate

from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse
from .models import ResumeUpload
import json

def upload_resume(request):
    if request.method == 'POST' and request.FILES.get('resume'):
        resume_file = request.FILES['resume']
        position = request.POST.get('position', 'Not specified')
        
        # Save the resume
        resume = ResumeUpload(
            file_name=resume_file.name,
            file=resume_file,
            position=position
        )
        resume.save()
        
        return JsonResponse({'success': True, 'id': resume.id})
    
    return render(request, 'upload.html')

def hr_dashboard(request):
    resumes = ResumeUpload.objects.all().order_by('-upload_date')
    return render(request, 'hrmanager.html', {'resumes': resumes})

def view_resume(request, resume_id):
    try:
        resume = ResumeUpload.objects.get(id=resume_id)
        response = HttpResponse(resume.file, content_type='application/pdf')
        response['Content-Disposition'] = f'inline; filename="{resume.file_name}"'
        return response
    except ResumeUpload.DoesNotExist:
        return HttpResponse("Resume not found", status=404)

def update_status(request, resume_id):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            status = data.get('status')
            
            resume = ResumeUpload.objects.get(id=resume_id)
            resume.status = status
            resume.save()
            
            return JsonResponse({'success': True})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'success': False, 'error': 'Method not allowed'}, status=405)


# edit profile and profile
# views.py

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Profile, Skill
from .forms import ProfileForm, UserForm

@login_required
def user_profile(request):
    """
    View function for displaying the user's profile.
    """
    user = request.user
    profile = get_object_or_404(Profile, user=user)
    
    context = {
        'user': user,
        'profile': profile,
    }
    
    return render(request, 'users/profile.html', context)

@login_required
def edit_profile(request):
    """
    View function for editing the user's profile.
    """
    user = request.user
    profile = get_object_or_404(Profile, user=user)
    user_skills = profile.skills.all()
    
    if request.method == 'POST':
        user_form = UserForm(request.POST, instance=user)
        profile_form = ProfileForm(request.POST, request.FILES, instance=profile)
        
        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_instance = profile_form.save(commit=False)
            profile_instance.user = user
            profile_instance.save()
            
            # Handle skills
            # Clear existing skills
            profile.skills.clear()
            
            # Add existing skills
            if 'skills' in request.POST:
                skill_ids = request.POST.getlist('skills')
                for skill_id in skill_ids:
                    skill = get_object_or_404(Skill, id=skill_id)
                    profile.skills.add(skill)
            
            # Add new skills
            if 'new_skills' in request.POST:
                new_skills = request.POST.getlist('new_skills')
                for skill_name in new_skills:
                    skill, created = Skill.objects.get_or_create(name=skill_name)
                    profile.skills.add(skill)
            
            messages.success(request, 'Your profile has been updated successfully!')
            return redirect('user_profile')
    else:
        user_form = UserForm(instance=user)
        profile_form = ProfileForm(instance=profile)
    
    context = {
        'form': profile_form,
        'user_form': user_form,
        'user_skills': user_skills,
    }
    
    return render(request, 'users/edit_profile.html', context)

#API INTEGRTATION 
import os
import re
import json
import anthropic
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST

class ClaudeResumeAnalyzer:
    def __init__(self):
        # Use environment variable for API key
        self.client = anthropic.Anthropic(
            api_key=os.environ.get('ANTHROPIC_API_KEY')
        )

    def analyze_resume(self, resume_text, position):
        """
        Analyze resume using Claude API
        """
        try:
            message = self.client.messages.create(
                model="claude-3-sonnet-20240229",
                max_tokens=1000,
                messages=[
                    {
                        "role": "user",
                        "content": f"""Perform a comprehensive ATS (Applicant Tracking System) analysis of the following resume for a {position} position:

Resume Text:
{resume_text}

Please provide:
1. Overall Matching Score (0-100)
2. Top 5 Matched Keywords
3. Top 5 Missing Keywords
4. Detailed Improvement Suggestions"""
                    }
                ]
            )
            
            # Parse the response
            analysis_text = message.content[0].text
            
            return self._parse_claude_response(analysis_text, position)
        
        except Exception as e:
            return {
                'error': str(e),
                'score': 50,
                'feedback': 'Analysis could not be completed.',
                'keywordMatches': [],
                'missingKeywords': [],
                'improvedContent': 'Please try again or check your resume.'
            }

    def _parse_claude_response(self, response_text, position):
        """
        Parse Claude's response into structured data
        """
        try:
            # Extract score
            score_match = re.search(r'Matching Score[:\s]*(\d+)', response_text, re.IGNORECASE)
            score = int(score_match.group(1)) if score_match else 50

            # Extract matched keywords
            matched_keywords_match = re.search(r'Matched Keywords?[:\s]*(.*?)Missing', response_text, re.DOTALL | re.IGNORECASE)
            matched_keywords = matched_keywords_match.group(1).split(',')[:5] if matched_keywords_match else []
            matched_keywords = [kw.strip() for kw in matched_keywords]

            # Extract missing keywords
            missing_keywords_match = re.search(r'Missing Keywords?[:\s]*(.*?)Improvement', response_text, re.DOTALL | re.IGNORECASE)
            missing_keywords = missing_keywords_match.group(1).split(',')[:5] if missing_keywords_match else []
            missing_keywords = [kw.strip() for kw in missing_keywords]

            return {
                'score': score,
                'feedback': f"ATS Analysis for {position} position",
                'keywordMatches': matched_keywords,
                'missingKeywords': missing_keywords,
                'improvedContent': response_text
            }
        except Exception as e:
            return {
                'score': 50,
                'feedback': 'Parsing failed',
                'keywordMatches': [],
                'missingKeywords': [],
                'improvedContent': str(e)
            }

@csrf_exempt
@require_POST
def analyze_resume(request):
    """
    Django view to handle resume analysis
    """
    try:
        # Parse incoming JSON data
        data = json.loads(request.body)
        resume_text = data.get('resumeText', '')
        position = data.get('position', 'General')

        # Validate input
        if not resume_text:
            return JsonResponse({
                'error': 'No resume text provided',
                'status': 'error'
            }, status=400)

        # Perform analysis
        analyzer = ClaudeResumeAnalyzer()
        analysis_result = analyzer.analyze_resume(resume_text, position)

        return JsonResponse(analysis_result)
    
    except Exception as e:
        return JsonResponse({
            'error': str(e),
            'status': 'error'
        }, status=500)