from django.urls import path
from .import views
from .views import index, resume, upload, option, signup, results, profile, login, candidate, hrmanager
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    
    path('', index, name='talentShield'),
    path('resumebuilder.html', resume, name='resumepage'),
    path('upload.html', upload, name='uploadpage'),
    path('option.html', option, name='optionpage'),
    path('signup.html', signup, name='signuppage'),
    path('results.html', results, name='resultpage'),
    path('profile.html', profile, name='profilepage'),
    path('login.html', login, name='loginpage'),
    path('candidate.html', candidate, name='candidatepage'),
    path('hrmanager.html', hrmanager, name='hrmanagerpage'),
   
    path('resume/', views.resume, name='resume'),
    path("generate-pdf/", views.generate_pdf, name="generate_pdf"),path('upload/', views.upload_resume, name='upload_resume'),
    path('hr-dashboard/', views.hr_dashboard, name='hr_dashboard'),
    path('view-resume/<int:resume_id>/', views.view_resume, name='view_resume'),
    path('update-status/<int:resume_id>/', views.update_status, name='update_status'),
    
    #profile and edit profile
    path('profile/', views.user_profile, name='user_profile'),
    path('profile/edit/', views.edit_profile, name='edit_profile'),
    path('candidate-dashboard/', views.candidate_dashboard, name='candidate_dashboard'),
    path('upload/', views.upload_documents, name='upload_documents'),
    path('logout/', views.logout_view, name='logout'),
    path('analyze-resume/', views.analyze_resume, name='analyze_resume'),

    
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
